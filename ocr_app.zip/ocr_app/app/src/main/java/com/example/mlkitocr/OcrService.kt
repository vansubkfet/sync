package com.example.mlkitocr

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log

import fi.iki.elonen.NanoHTTPD
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.runBlocking

class OcrService : Service() {

    companion object {

        private const val TAG =
            "MLKitOCR-Service"

        private const val CHANNEL_ID =
            "mlkit_ocr_server"

        private const val NOTIFICATION_ID =
            1001

        private const val HTTP_PORT =
            8080

        const val ACTION_START =
            "com.example.mlkitocr.START"

        const val ACTION_STOP =
            "com.example.mlkitocr.STOP"
    }

    private val serviceScope =
        CoroutineScope(
            SupervisorJob() +
                Dispatchers.Default
        )

    private lateinit var ocrEngine: OcrEngine

    private lateinit var ocrQueue: OcrQueue

    private lateinit var httpServer: OcrHttpServer

    override fun onCreate() {

        super.onCreate()

        Log.i(
            TAG,
            "Creating OCR service"
        )

        createNotificationChannel()

        startForeground(
            NOTIFICATION_ID,
            createNotification(),
            android.content.pm.ServiceInfo
                .FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )

        ocrEngine =
            OcrEngine()

        ocrEngine.initialize()

        ocrQueue =
            OcrQueue(
                engine = ocrEngine,
                scope = serviceScope,
                capacity = 8,
                timeoutMs = 30_000L
            )

        ocrQueue.start()

        httpServer =
            OcrHttpServer(
                ocrQueue
            )

        try {

            httpServer.start(
                NanoHTTPD.SOCKET_READ_TIMEOUT,
                false
            )

            Log.i(
                TAG,
                "OCR HTTP server started on port $HTTP_PORT"
            )

        } catch (e: Exception) {

            Log.e(
                TAG,
                "Failed to start HTTP server",
                e
            )

            stopSelf()
        }
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {

        Log.i(
            TAG,
            "onStartCommand action=${intent?.action}"
        )

        if (intent?.action == ACTION_STOP) {

            stopSelf()

            return START_NOT_STICKY
        }

        return START_STICKY
    }

    override fun onDestroy() {

        Log.i(
            TAG,
            "Stopping OCR service"
        )

        if (::httpServer.isInitialized) {
            try {
                httpServer.stop()
            } catch (e: Exception) {
                Log.e(
                    TAG,
                    "Failed to stop HTTP server",
                    e
                )
            }
        }

        if (::ocrQueue.isInitialized) {
            runBlocking {
                ocrQueue.shutdown()
            }
        }

        if (::ocrEngine.isInitialized) {
            try {
                ocrEngine.close()
            } catch (e: Exception) {
                Log.e(
                    TAG,
                    "Failed to close OCR engine",
                    e
                )
            }
        }

        serviceScope.cancel()

        super.onDestroy()
    }

    override fun onBind(
        intent: Intent?
    ): IBinder? {

        return null
    }

    private fun createNotificationChannel() {

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.O
        ) {

            val channel =
                NotificationChannel(
                    CHANNEL_ID,
                    "MLKit OCR Server",
                    NotificationManager
                        .IMPORTANCE_LOW
                ).apply {

                    description =
                        "Local ML Kit OCR server"

                    setShowBadge(false)
                }

            val manager =
                getSystemService(
                    NotificationManager::class.java
                )

            manager.createNotificationChannel(
                channel
            )
        }
    }

    private fun createNotification():
        Notification {

        return if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.O
        ) {

            Notification.Builder(
                this,
                CHANNEL_ID
            )
                .setContentTitle(
                    "MLKit OCR Server"
                )
                .setContentText(
                    "OCR server is running on port $HTTP_PORT"
                )
                .setSmallIcon(
                    android.R.drawable.ic_menu_search
                )
                .setOngoing(true)
                .setCategory(
                    Notification.CATEGORY_SERVICE
                )
                .build()

        } else {

            Notification.Builder(this)
                .setContentTitle(
                    "MLKit OCR Server"
                )
                .setContentText(
                    "OCR server is running"
                )
                .setSmallIcon(
                    android.R.drawable.ic_menu_search
                )
                .setOngoing(true)
                .build()
        }
    }
}