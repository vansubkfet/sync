package com.example.mlkitocr

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.exifinterface.media.ExifInterface
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.ByteArrayInputStream
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class OcrEngine {

    companion object {
        private const val MAX_IMAGE_WIDTH = 8000
        private const val MAX_IMAGE_HEIGHT = 8000
    }

    private val recognizer by lazy {
        TextRecognition.getClient(
            TextRecognizerOptions.DEFAULT_OPTIONS
        )
    }

    fun initialize() {
        // Force lazy initialization.
        recognizer
    }

    suspend fun recognize(
        imageBytes: ByteArray
    ): OcrResult {

        require(imageBytes.isNotEmpty()) {
            "Image is empty"
        }

        val bounds = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }

        BitmapFactory.decodeByteArray(
            imageBytes,
            0,
            imageBytes.size,
            bounds
        )

        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw IllegalArgumentException(
                "Invalid or unsupported image"
            )
        }

        if (
            bounds.outWidth > MAX_IMAGE_WIDTH ||
            bounds.outHeight > MAX_IMAGE_HEIGHT
        ) {
            throw IllegalArgumentException(
                "Image dimensions exceed maximum allowed size: " +
                    "${MAX_IMAGE_WIDTH}x${MAX_IMAGE_HEIGHT}"
            )
        }

        val bitmap = BitmapFactory.decodeByteArray(
            imageBytes,
            0,
            imageBytes.size,
            BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
        )
            ?: throw IllegalArgumentException(
                "Unable to decode image"
            )

        val correctedBitmap =
            applyExifOrientation(
                imageBytes,
                bitmap
            )

        if (correctedBitmap !== bitmap) {
            bitmap.recycle()
        }

        return try {

            recognizeBitmap(correctedBitmap)

        } finally {

            correctedBitmap.recycle()
        }
    }

    private suspend fun recognizeBitmap(
        bitmap: Bitmap
    ): OcrResult {

        val image =
            InputImage.fromBitmap(
                bitmap,
                0
            )

        val startTime =
            System.currentTimeMillis()

        val result =
            suspendCancellableCoroutine<Text> { continuation ->

                recognizer
                    .process(image)
                    .addOnSuccessListener { result ->
                        if (continuation.isActive) {
                            continuation.resume(result)
                        }
                    }
                    .addOnFailureListener { exception ->
                        if (continuation.isActive) {
                            continuation.resumeWithException(
                                exception
                            )
                        }
                    }
            }

        val elapsed =
            System.currentTimeMillis() - startTime

        return OcrResult(
            text = result.text,
            processingTimeMs = elapsed,
            imageWidth = bitmap.width,
            imageHeight = bitmap.height,
            blocks = result.textBlocks.map { block ->

                OcrBlock(
                    text = block.text,

                    lines = block.lines.map { line ->

                        OcrLine(
                            text = line.text,

                            boundingBox =
                                line.boundingBox?.let {
                                    BoundingBox(
                                        left = it.left,
                                        top = it.top,
                                        right = it.right,
                                        bottom = it.bottom
                                    )
                                }
                        )
                    },

                    boundingBox =
                        block.boundingBox?.let {
                            BoundingBox(
                                left = it.left,
                                top = it.top,
                                right = it.right,
                                bottom = it.bottom
                            )
                        }
                )
            }
        )
    }

    private fun applyExifOrientation(
        imageBytes: ByteArray,
        bitmap: Bitmap
    ): Bitmap {

        val exif = try {

            ExifInterface(
                ByteArrayInputStream(imageBytes)
            )

        } catch (_: Exception) {

            return bitmap
        }

        val orientation =
            exif.getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )

        val matrix = Matrix()

        when (orientation) {

            ExifInterface.ORIENTATION_ROTATE_90 ->
                matrix.postRotate(90f)

            ExifInterface.ORIENTATION_ROTATE_180 ->
                matrix.postRotate(180f)

            ExifInterface.ORIENTATION_ROTATE_270 ->
                matrix.postRotate(270f)

            ExifInterface.ORIENTATION_FLIP_HORIZONTAL ->
                matrix.preScale(-1f, 1f)

            ExifInterface.ORIENTATION_FLIP_VERTICAL ->
                matrix.preScale(1f, -1f)

            ExifInterface.ORIENTATION_TRANSPOSE -> {
                matrix.preScale(-1f, 1f)
                matrix.postRotate(270f)
            }

            ExifInterface.ORIENTATION_TRANSVERSE -> {
                matrix.preScale(-1f, 1f)
                matrix.postRotate(90f)
            }

            else ->
                return bitmap
        }

        return Bitmap.createBitmap(
            bitmap,
            0,
            0,
            bitmap.width,
            bitmap.height,
            matrix,
            true
        )
    }

    fun close() {
        recognizer.close()
    }
}