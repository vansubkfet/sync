package com.example.mlkitocr

import android.util.Log
import fi.iki.elonen.NanoHTTPD
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.UUID

class OcrHttpServer(
    private val ocrQueue: OcrQueue
) : NanoHTTPD(8080) {

    companion object {

        private const val TAG =
            "MLKitOCR-HTTP"

        private const val MAX_BODY_SIZE =
            10 * 1024 * 1024

        private const val REQUEST_TIMEOUT_MS =
            35_000L
    }

    override fun serve(
        session: IHTTPSession
    ): Response {

        val requestId =
            session.headers["x-request-id"]
                ?.takeIf { it.isNotBlank() }
                ?: UUID.randomUUID().toString()

        return try {

            when {

                session.method == Method.GET &&
                    session.uri == "/health" -> {

                    jsonResponse(
                        Response.Status.OK,
                        JSONObject()
                            .put("status", "ok")
                            .put(
                                "service",
                                "mlkit-ocr"
                            )
                            .put(
                                "requestId",
                                requestId
                            )
                            .toString()
                    )
                }

                session.method == Method.GET &&
                    session.uri == "/ready" -> {

                    jsonResponse(
                        Response.Status.OK,
                        JSONObject()
                            .put(
                                "status",
                                "ready"
                            )
                            .put(
                                "requestId",
                                requestId
                            )
                            .toString()
                    )
                }

                session.method == Method.GET &&
                    session.uri == "/info" -> {

                    jsonResponse(
                        Response.Status.OK,
                        JSONObject()
                            .put(
                                "service",
                                "mlkit-ocr"
                            )
                            .put(
                                "version",
                                "1.0.0"
                            )
                            .put(
                                "queueCapacity",
                                8
                            )
                            .put(
                                "activeJobs",
                                ocrQueue.activeJobs()
                            )
                            .put(
                                "acceptedJobs",
                                ocrQueue.acceptedJobs()
                            )
                            .put(
                                "completedJobs",
                                ocrQueue.completedJobs()
                            )
                            .put(
                                "requestId",
                                requestId
                            )
                            .toString()
                    )
                }

                session.method == Method.POST &&
                    session.uri == "/ocr" -> {

                    handleOcr(
                        session,
                        requestId
                    )
                }

                else -> {

                    jsonResponse(
                        Response.Status.NOT_FOUND,
                        JSONObject()
                            .put(
                                "error",
                                "NOT_FOUND"
                            )
                            .put(
                                "message",
                                "Endpoint not found"
                            )
                            .put(
                                "requestId",
                                requestId
                            )
                            .toString()
                    )
                }
            }

        } catch (e: Exception) {

            Log.e(
                TAG,
                "Request failed requestId=$requestId",
                e
            )

            jsonResponse(
                Response.Status.INTERNAL_ERROR,
                JSONObject()
                    .put(
                        "error",
                        "INTERNAL_ERROR"
                    )
                    .put(
                        "message",
                        "Internal server error"
                    )
                    .put(
                        "requestId",
                        requestId
                    )
                    .toString()
            )
        }
    }

    private fun handleOcr(
        session: IHTTPSession,
        requestId: String
    ): Response {

        val contentType =
            session.headers["content-type"]
                ?.lowercase()
                ?.split(";")
                ?.firstOrNull()
                ?.trim()

        if (
            contentType != "image/jpeg" &&
            contentType != "image/png" &&
            contentType != "image/webp"
        ) {

            return jsonResponse(
                Response.Status.BAD_REQUEST,
                JSONObject()
                    .put(
                        "error",
                        "UNSUPPORTED_MEDIA_TYPE"
                    )
                    .put(
                        "message",
                        "Supported content types: image/jpeg, image/png, image/webp"
                    )
                    .put(
                        "requestId",
                        requestId
                    )
                    .toString()
            )
        }

        val contentLength =
            session.headers["content-length"]
                ?.toLongOrNull()

        if (contentLength == null) {

            return jsonResponse(
                Response.Status.BAD_REQUEST,
                JSONObject()
                    .put(
                        "error",
                        "CONTENT_LENGTH_REQUIRED"
                    )
                    .put(
                        "message",
                        "Content-Length is required"
                    )
                    .put(
                        "requestId",
                        requestId
                    )
                    .toString()
            )
        }

        if (contentLength <= 0) {

            return jsonResponse(
                Response.Status.BAD_REQUEST,
                JSONObject()
                    .put(
                        "error",
                        "EMPTY_BODY"
                    )
                    .put(
                        "message",
                        "Image body is empty"
                    )
                    .put(
                        "requestId",
                        requestId
                    )
                    .toString()
            )
        }

        if (contentLength > MAX_BODY_SIZE) {

            return jsonResponse(
                Response.Status.BAD_REQUEST,
                JSONObject()
                    .put(
                        "error",
                        "IMAGE_TOO_LARGE"
                    )
                    .put(
                        "message",
                        "Maximum image size is 10 MB"
                    )
                    .put(
                        "requestId",
                        requestId
                    )
                    .toString()
            )
        }

        val imageBytes =
            try {

                readBody(
                    session,
                    contentLength
                )

            } catch (e: IOException) {

                return jsonResponse(
                    Response.Status.BAD_REQUEST,
                    JSONObject()
                        .put(
                            "error",
                            "INVALID_BODY"
                        )
                        .put(
                            "message",
                            "Unable to read request body"
                        )
                        .put(
                            "requestId",
                            requestId
                        )
                        .toString()
                )
            }

        val deferred =
            ocrQueue.trySubmit(
                imageBytes
            )

        if (deferred == null) {

            return jsonResponse(
                Response.Status.TOO_MANY_REQUESTS,
                JSONObject()
                    .put(
                        "error",
                        "OCR_QUEUE_FULL"
                    )
                    .put(
                        "message",
                        "OCR server is busy"
                    )
                    .put(
                        "requestId",
                        requestId
                    )
                    .toString()
            )
        }

        return try {

            val result =
                runBlocking {

                    withTimeout(
                        REQUEST_TIMEOUT_MS
                    ) {
                        deferred.await()
                    }
                }

            jsonResponse(
                Response.Status.OK,
                resultToJson(
                    result,
                    requestId
                ).toString()
            )

        } catch (e: kotlinx.coroutines.TimeoutCancellationException) {

            Log.w(
                TAG,
                "OCR timeout requestId=$requestId"
            )

            jsonResponse(
                Response.Status.GATEWAY_TIMEOUT,
                JSONObject()
                    .put(
                        "error",
                        "OCR_TIMEOUT"
                    )
                    .put(
                        "message",
                        "OCR processing timed out"
                    )
                    .put(
                        "requestId",
                        requestId
                    )
                    .toString()
            )

        } catch (e: IllegalArgumentException) {

            jsonResponse(
                Response.Status.BAD_REQUEST,
                JSONObject()
                    .put(
                        "error",
                        "INVALID_IMAGE"
                    )
                    .put(
                        "message",
                        e.message ?: "Invalid image"
                    )
                    .put(
                        "requestId",
                        requestId
                    )
                    .toString()
            )

        } catch (e: Exception) {

            Log.e(
                TAG,
                "OCR failed requestId=$requestId",
                e
            )

            jsonResponse(
                Response.Status.INTERNAL_ERROR,
                JSONObject()
                    .put(
                        "error",
                        "OCR_FAILED"
                    )
                    .put(
                        "message",
                        "OCR processing failed"
                    )
                    .put(
                        "requestId",
                        requestId
                    )
                    .toString()
            )
        }
    }

    private fun readBody(
        session: IHTTPSession,
        contentLength: Long
    ): ByteArray {

        if (contentLength > MAX_BODY_SIZE) {
            throw IOException(
                "Request body too large"
            )
        }

        val output =
            ByteArrayOutputStream(
                contentLength.toInt()
            )

        val buffer =
            ByteArray(8192)

        var remaining =
            contentLength

        while (remaining > 0) {

            val toRead =
                minOf(
                    remaining,
                    buffer.size.toLong()
                ).toInt()

            val read =
                session.inputStream.read(
                    buffer,
                    0,
                    toRead
                )

            if (read < 0) {
                throw IOException(
                    "Unexpected end of request body"
                )
            }

            output.write(
                buffer,
                0,
                read
            )

            remaining -= read
        }

        return output.toByteArray()
    }

    private fun resultToJson(
        result: OcrResult,
        requestId: String
    ): JSONObject {

        val blocks =
            JSONArray()

        for (block in result.blocks) {

            val lines =
                JSONArray()

            for (line in block.lines) {

                val lineJson =
                    JSONObject()
                        .put(
                            "text",
                            line.text
                        )

                line.boundingBox?.let {

                    lineJson.put(
                        "boundingBox",
                        boundingBoxToJson(it)
                    )
                }

                lines.put(lineJson)
            }

            val blockJson =
                JSONObject()
                    .put(
                        "text",
                        block.text
                    )
                    .put(
                        "lines",
                        lines
                    )

            block.boundingBox?.let {

                blockJson.put(
                    "boundingBox",
                    boundingBoxToJson(it)
                )
            }

            blocks.put(blockJson)
        }

        return JSONObject()
            .put(
                "requestId",
                requestId
            )
            .put(
                "text",
                result.text
            )
            .put(
                "processingTimeMs",
                result.processingTimeMs
            )
            .put(
                "image",
                JSONObject()
                    .put(
                        "width",
                        result.imageWidth
                    )
                    .put(
                        "height",
                        result.imageHeight
                    )
            )
            .put(
                "blocks",
                blocks
            )
    }

    private fun boundingBoxToJson(
        box: BoundingBox
    ): JSONObject {

        return JSONObject()
            .put("left", box.left)
            .put("top", box.top)
            .put("right", box.right)
            .put("bottom", box.bottom)
    }

    private fun jsonResponse(
        status: Response.Status,
        body: String
    ): Response {

        return newFixedLengthResponse(
            status,
            "application/json; charset=utf-8",
            body
        )
    }
}