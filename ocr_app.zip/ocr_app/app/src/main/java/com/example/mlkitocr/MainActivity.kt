package com.example.mlkitocr

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log

class MainActivity : Activity() {

    companion object {

        private const val TAG =
            "MLKitOCR-Activity"
    }

    override fun onCreate(
        savedInstanceState: Bundle?
    ) {

        super.onCreate(
            savedInstanceState
        )

        Log.i(
            TAG,
            "Starting OCR service"
        )

        val intent =
            Intent(
                this,
                OcrService::class.java
            ).apply {
                action =
                    OcrService.ACTION_START
            }

        startForegroundService(intent)

        /*
         * This application is a headless server.
         *
         * The Activity is intentionally not responsible
         * for the OCR server lifecycle.
         */
        finish()
    }

    override fun onDestroy() {

        Log.i(
            TAG,
            "MainActivity destroyed"
        )

        super.onDestroy()
    }
}