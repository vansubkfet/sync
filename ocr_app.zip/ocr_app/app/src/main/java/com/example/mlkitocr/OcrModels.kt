package com.example.mlkitocr

data class OcrResult(
    val text: String,
    val processingTimeMs: Long,
    val imageWidth: Int,
    val imageHeight: Int,
    val blocks: List<OcrBlock>
)

data class OcrBlock(
    val text: String,
    val lines: List<OcrLine>,
    val boundingBox: BoundingBox?
)

data class OcrLine(
    val text: String,
    val boundingBox: BoundingBox?
)

data class BoundingBox(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int
)