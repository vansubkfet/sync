package com.example.mlkitocr

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout

class OcrQueue(
    private val engine: OcrEngine,
    private val scope: CoroutineScope,
    private val capacity: Int = 8,
    private val timeoutMs: Long = 30_000L
) {

    private data class Job(
        val imageBytes: ByteArray,
        val result: CompletableDeferred<OcrResult>
    )

    private val channel =
        Channel<Job>(capacity)

    @Volatile
    private var running = false

    @Volatile
    private var activeJobs = 0

    @Volatile
    private var acceptedJobs = 0L

    @Volatile
    private var completedJobs = 0L

    fun start() {

        if (running) {
            return
        }

        running = true

        scope.launch(Dispatchers.Default) {

            for (job in channel) {

                activeJobs++

                try {

                    val result =
                        withTimeout(timeoutMs) {
                            engine.recognize(
                                job.imageBytes
                            )
                        }

                    job.result.complete(result)

                } catch (e: Exception) {

                    job.result.completeExceptionally(
                        e
                    )

                } finally {

                    activeJobs--
                    completedJobs++
                }
            }
        }
    }

    fun trySubmit(
        imageBytes: ByteArray
    ): CompletableDeferred<OcrResult>? {

        if (!running) {
            return null
        }

        val result =
            CompletableDeferred<OcrResult>()

        val job =
            Job(
                imageBytes = imageBytes,
                result = result
            )

        if (!channel.trySend(job).isSuccess) {
            return null
        }

        acceptedJobs++

        return result
    }

    fun activeJobs(): Int =
        activeJobs

    fun acceptedJobs(): Long =
        acceptedJobs

    fun completedJobs(): Long =
        completedJobs

    suspend fun shutdown() {

        running = false

        channel.close()
    }
}